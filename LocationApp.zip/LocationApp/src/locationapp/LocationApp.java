/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package locationapp;

import java.util.List;
import location.app.model.EngineLocator;
import location.app.model.Grid;
import location.app.model.GridLocation;
import location.app.model.Grids;
import location.app.model.Location;
import java.io.FileWriter;
import weka.*;

/**
 *
 * @author Oluwaseun
 */
public class LocationApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String file = "C:/Users/Oluwaseun/Documents/Fresh/GridClassification/GeotagsUS2.csv";
        GridLocation gridLocation = EngineLocator.buildLocation(file);
        Grids.loadGrid(gridLocation);
        
        List<Location> locations = EngineLocator.buildLocations(file);
        System.out.println("locations returned: " + locations.size());
        
        for(Location location : locations){
            Grid grid = Grids.findLocation(location);
            /*System.out.println(location);
            System.out.println("*********************************");
            System.out.println("*\tGrid number: " + grid + "\t*");
            System.out.println("*********************************");
                   */
            System.out.println(location + ", " + grid);
        }
    }
    
}
