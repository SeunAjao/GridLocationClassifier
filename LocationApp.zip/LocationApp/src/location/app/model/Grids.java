/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package location.app.model;

import java.text.DecimalFormat;

/**
 *
 * @author Oluwaseun
 */
public class Grids {
    
    private static DecimalFormat df = new DecimalFormat("#.00000000"); 
    
    private static final int COLUMNS = 32;
    private static final int ROWS = 32;
    
    private static final Grid[][] grids = new Grid[ROWS][COLUMNS];
    
    public static void loadGrid(GridLocation location){
        double maxLongittude;
        double minLongittude = location.getMinLong();
        
        double increLattitude = Double.valueOf(df.format(Math.abs((location.getMaxLat() - location.getMinLat()) / ROWS)));
        double increLongittitude = Double.valueOf(df.format(Math.abs((location.getMaxLong() - location.getMinLong()) / COLUMNS)));
        
        double minLattitude = location.getMinLat();
        double maxLattitude = minLattitude + increLattitude;
        Grid grid;
        int no = 1;
        for (Grid[] grid1 : grids) {
            for (int j = 0; j < grid1.length; j++) {
                grid = new Grid();
                grid.setGridNo(no).setMinLat(minLattitude);
                grid.setMaxLat(maxLattitude);
                grid.setMinLong(minLongittude);
                maxLongittude = minLongittude + increLongittitude;
                grid.setMaxLong(maxLongittude);
                grid1[j] = grid;
                
                minLongittude = maxLongittude;
                no++;
            }
            minLattitude = maxLattitude;
            maxLattitude = minLattitude + increLattitude;
            minLongittude = location.getMinLong();
        }
    }
    
    public static Grid findLocation(Location location){
        Grid grid = null;
        for (Grid[] row : grids) {
            for (Grid col : row) {
                
                if(location.getLongitude()>= col.getMinLong() 
                    && location.getLongitude() < col.getMaxLong()
                    && location.getLattitude()>= col.getMinLat()
                    && location.getLattitude() <= col.getMaxLat()
                        ){
                    grid = col;
                }
                if(grid != null){
                    break;
                }
            }
        }
        return grid;
    }
    
}
