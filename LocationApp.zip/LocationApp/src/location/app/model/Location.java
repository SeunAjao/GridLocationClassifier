/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package location.app.model;

/**
 *
 * @author Oluwaseun
 */
public class Location {
    
    private double lattitude;
    private double longitude;
    
    private double maxLat;
    private double minLat;
    private double maxLong;
    private double minLong;

    public Location() {
    }

    public Location(double lattitude, double longitude) {
        this.lattitude = lattitude;
        this.longitude = longitude;
    }
    
    public double getLattitude() {
        return lattitude;
    }

    public void setLattitude(double lattitude) {
        this.lattitude = lattitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
    
    @Override
    public String toString(){
        /**return "Location: " 
                + "\nLatitude = " + lattitude               
                + "\nLongitude = " + longitude ;
        */
       return lattitude + ", " + longitude;
    }
}
