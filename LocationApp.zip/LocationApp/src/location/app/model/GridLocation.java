/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package location.app.model;

/**
 *
 * @author Oluwaseun
 */
public class GridLocation {
    
    private double maxLat;
    private double minLat;
    private double maxLong;
    private double minLong;

    public GridLocation() {
    }

    public GridLocation(double maxLat, double minLat, double maxLong, double minLong) {
        this.maxLat = maxLat;
        this.minLat = minLat;
        this.maxLong = maxLong;
        this.minLong = minLong;
    }

    public double getMaxLat() {
        return maxLat;
    }

    public GridLocation setMaxLat(double maxLat) {
        this.maxLat = maxLat;
        return this;
    }

    public double getMinLat() {
        return minLat;
    }

    public GridLocation setMinLat(double minLat) {
        this.minLat = minLat;
        return this;
    }

    public double getMaxLong() {
        return maxLong;
    }

    public GridLocation setMaxLong(double maxLong) {
        this.maxLong = maxLong;
        return this;
    }

    public double getMinLong() {
        return minLong;
    }

    public GridLocation setMinLong(double minLong) {
        this.minLong = minLong;
        return this;
    }   
    
    @Override
    public String toString(){
        return "Location: " 
                + "\nMaximum Latitude = " + maxLat 
                + "\nMinimum Latitude = " + minLat 
                +"\nMaximum Longitude = " + maxLong
                +"\nMinimum Longitude = " + minLong;
    }
}
