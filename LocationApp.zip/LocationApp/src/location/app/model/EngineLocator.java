/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package location.app.model;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Oluwaseun
 */
public class EngineLocator {
    
    private static final String DELIMITER = ",";
    
    private static double maxLat = Integer.MIN_VALUE;
    private static double minLat = Integer.MAX_VALUE;
    private static double maxLong = Integer.MIN_VALUE;
    private static double minLong = Integer.MAX_VALUE;
    
    private static void calculateMinAndMaxLat(ArrayList<String> lines) {
        for (String line : lines) {
            //check the max value
            double currentValue = Double.parseDouble(line);
            if (currentValue > maxLat) {
                maxLat = currentValue;
            } //check the min value
            else if (currentValue < minLat) {
                minLat = currentValue;
            }
        }
    }

    private static void calculateMinAndMaxLong(ArrayList<String> lines) {
        for (String line : lines) {
            //check the max value
            double currentValue = Double.parseDouble(line);
            if (currentValue > maxLong) {
                maxLong = currentValue;
            } else if (currentValue < minLong) {
                minLong = currentValue;
            }
        }
    }
    
    public static List<Location> buildLocations(String csvFile){
        
        BufferedReader br = null;
        String line;
        List<Location> locations = new ArrayList<>();
        
        try {

            br = new BufferedReader(new FileReader(csvFile));
            Location location;
            while ((line = br.readLine()) != null) {
                

                // use comma as separator
                String[] tweet = line.split(DELIMITER);
                location = new Location(new Double(tweet[0]), new Double(tweet[1]));
                locations.add(location);
            }
            
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }        
        return locations;
    }
    
    public static GridLocation buildLocation(String csvFile){
        
        BufferedReader br = null;
        String line;
        ArrayList<String> listLat = new ArrayList<>();
        ArrayList<String> listLong = new ArrayList<>();
        try {

            br = new BufferedReader(new FileReader(csvFile));

            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] tweet = line.split(DELIMITER);
                listLat.add(tweet[0]);
                listLong.add(tweet[1]);
            }
            calculateMinAndMaxLat(listLat);
            calculateMinAndMaxLong(listLong);
            
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }        
        return (new GridLocation()).setMaxLat(maxLat).setMinLat(minLat).setMaxLong(maxLong).setMinLong(minLong);
    }    
}
