/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package location.app.model;

/**
 *
 * @author Oluwaseun
 */
public class Grid {
    
    private int gridNo;
    private double minLong;
    private double maxLong;
    private double minLat;
    private double maxLat;

    public Grid() {
    }

    public Grid(int gridNo, double minLong, double maxLong, double minLat, double maxLat) {
        this.gridNo = gridNo;
        this.minLong = minLong;
        this.maxLong = maxLong;
        this.minLat = minLat;
        this.maxLat = maxLat;
    }

    public int getGridNo() {
        return gridNo;
    }

    public Grid setGridNo(int gridNo) {
        this.gridNo = gridNo;
        return this;
    }

    public double getMinLong() {
        return minLong;
    }

    public Grid setMinLong(double minLong) {
        this.minLong = minLong;
        return this;
    }

    public double getMaxLong() {
        return maxLong;
    }

    public Grid setMaxLong(double maxLong) {
        this.maxLong = maxLong;
        return this;
    }

    public double getMinLat() {
        return minLat;
    }

    public Grid setMinLat(double minLat) {
        this.minLat = minLat;
        return this;
    }

    public double getMaxLat() {
        return maxLat;
    }

    public Grid setMaxLat(double maxLat) {
        this.maxLat = maxLat;
        return this;
    }   
    
    @Override
    public String toString(){    
        return "G" + gridNo;
    }
}
